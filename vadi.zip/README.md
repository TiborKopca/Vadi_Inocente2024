# Vadi es inocente 
##### Landing page project - for singer Vadi**
- Colaborative project between two authors for the **Real Client**, pro bono

## Description & Functionality
- Design focused to show the video of the singer being kidnapped
- Brevo platform - form implemented to capture the subscibers
- Main content is focused to be shown on the mobile devices only

## Screenshot
![here](/screenshots/screenshot.png)

## Online Link
[github Pages Link](https://tiborkopca.github.io/Vadi_Inocente2024/)

## Authors

- [@TiborKopca](https://github.com/TiborKopca)
- [@LuisFerra](https://github.com/luisillo19)
